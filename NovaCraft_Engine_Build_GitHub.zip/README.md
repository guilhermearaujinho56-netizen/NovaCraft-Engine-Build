# NovaCraft — build remoto do motor Java Android

Este pacote contém uma receita de GitHub Actions para compilar o projeto Android Amethyst, que fornece o motor Java Android (runtime, camada gráfica e launcher) usado como base técnica.

**Importante:** este build produz o APK de teste do Amethyst sem rebranding nem integração com a interface NovaCraft 0.4. Ele não deve ser apresentado como APK final NovaCraft. A integração de interface, catálogo, perfis e autenticação ainda exige trabalho de desenvolvimento e testes.

## Como gerar o APK pelo celular

1. Crie/entre em uma conta GitHub.
2. Crie um repositório novo chamado `NovaCraft-Engine-Build`.
3. Envie os arquivos deste ZIP para a raiz do repositório, mantendo `.github/workflows/build-engine-apk.yml`.
4. Abra a aba **Actions** do repositório.
5. Se o fluxo não iniciar automaticamente, escolha **Build NovaCraft Java Engine APK (Amethyst base)** e toque em **Run workflow**.
6. Aguarde terminar. Abra a execução concluída, vá em **Artifacts** e baixe `NovaCraft-Java-Engine-test-APK`.
7. Extraia o ZIP do artifact e instale o APK no Android.

## O que este fluxo faz

- Usa JDK 17.
- Instala Android SDK no runner do GitHub.
- Clona Amethyst com seus submódulos.
- Executa `:app_pojavlauncher:assembleDebug`.
- Publica o APK debug como artifact por 7 dias.

## Limites e segurança

- O APK é uma compilação de teste do engine upstream, não o NovaCraft customizado.
- Não inclui chave de API CurseForge nem credenciais Microsoft.
- Use uma conta Microsoft/Minecraft legítima quando o launcher solicitar autenticação.
- Amethyst é software de terceiros; preserve avisos de copyright/licença e cumpra LGPLv3 e licenças das dependências ao redistribuir ou modificar.
- A compilação pode falhar se o upstream mudar dependências ou configuração. Consulte o log da execução no Actions.

Projeto upstream: https://github.com/AngelAuraMC/Amethyst-Android
