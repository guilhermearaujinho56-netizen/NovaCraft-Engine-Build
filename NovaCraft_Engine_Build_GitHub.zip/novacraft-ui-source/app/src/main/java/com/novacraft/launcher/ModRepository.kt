package com.novacraft.launcher

import com.google.gson.JsonParser
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest

class ModRepository {
 private val client=OkHttpClient()
 private fun get(url:String):String { val req=Request.Builder().url(url).header("User-Agent","NovaCraftLauncher/0.4").build(); client.newCall(req).execute().use { r -> if(!r.isSuccessful) error("HTTP ${r.code}"); return r.body?.string() ?: error("Resposta vazia") } }
 fun searchModrinth(query:String,version:String,loader:String):List<ModItem> {
  val q=java.net.URLEncoder.encode(query,"UTF-8")
  val facets= "[[\\"project_type:mod\\"],[\\"versions:$version\\"],[\\"categories:$loader\\"]]"
  val f=java.net.URLEncoder.encode(facets,"UTF-8")
  val root=JsonParser.parseString(get("https://api.modrinth.com/v2/search?query=$q&facets=$f&limit=30")).asJsonObject
  return root.getAsJsonArray("hits").map { e -> val o=e.asJsonObject; ModItem(o.get("title").asString,o.get("description").asString,o.get("downloads").asLong.toString(),"Modrinth",o.get("project_id").asString) }
 }
 fun downloadModrinth(projectId:String,version:String,loader:String):File {
  val url="https://api.modrinth.com/v2/project/$projectId/version?game_versions=%5B%22$version%22%5D&loaders=%5B%22$loader%22%5D"
  val arr=JsonParser.parseString(get(url)).asJsonArray
  val v=arr.firstOrNull()?.asJsonObject ?: error("Sem versão compatível para $version / $loader")
  val f=v.getAsJsonArray("files").first().asJsonObject
  val bytes=client.newCall(Request.Builder().url(f.get("url").asString).build()).execute().use { r -> if(!r.isSuccessful) error("Download HTTP ${r.code}"); r.body?.bytes() ?: error("Arquivo vazio") }
  val sha=f.getAsJsonObject("hashes")?.get("sha1")?.asString
  if(sha!=null) { val actual=MessageDigest.getInstance("SHA-1").digest(bytes).joinToString("") { "%02x".format(it) }; if(!actual.equals(sha,true)) error("SHA-1 inválido; arquivo descartado.") }
  val out=File.createTempFile("novacraft_",".jar"); out.writeBytes(bytes)
  val named=File(out.parentFile,f.get("filename").asString); if(!out.renameTo(named)) error("Não foi possível salvar o JAR"); return named
 }
}
