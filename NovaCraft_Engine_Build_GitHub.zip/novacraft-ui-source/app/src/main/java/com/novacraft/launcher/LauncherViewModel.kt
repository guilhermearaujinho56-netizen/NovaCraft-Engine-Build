package com.novacraft.launcher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

data class ModItem(val title:String,val description:String,val downloads:String,val source:String,val projectId:String)
data class LauncherState(val mcVersion:String="1.20.1",val loader:String="Fabric",val profile:String="Principal",val profiles:List<String> = listOf("Principal"),val ramGb:Int=1,val renderDistance:Int=4,val mods:List<ModItem> = emptyList(),val loading:Boolean=false,val installing:Boolean=false,val error:String?=null,val notice:String?="Busque mods no catálogo.",val launchMessage:String="Motor de execução não conectado.")
class LauncherViewModel(app:Application):AndroidViewModel(app) {
 private val repo=ModRepository(); private val _state=MutableStateFlow(LauncherState()); val state:StateFlow<LauncherState> = _state
 fun searchMods(q:String,source:String,version:String,loader:String) { viewModelScope.launch {
  _state.update { it.copy(loading=true,error=null,notice=null,mods=emptyList()) }
  runCatching { if(source=="CurseForge") error("CurseForge precisa de backend HTTPS com API key protegida. Não coloque a chave dentro do APK."); repo.searchModrinth(q,version,loader) }
   .onSuccess { _state.update { s -> s.copy(loading=false,mods=it,notice=if(it.isEmpty()) "Nenhum resultado." else null) } }
   .onFailure { e -> _state.update { it.copy(loading=false,error=e.message ?: "Falha na busca.") } }
 } }
 fun installMod(m:ModItem) { viewModelScope.launch {
  _state.update { it.copy(installing=true,error=null,notice="Baixando e verificando arquivo...") }
  runCatching { val downloaded=repo.downloadModrinth(m.projectId,_state.value.mcVersion,_state.value.loader.lowercase()); val dir=File(getApplication<Application>().filesDir,"profiles/${_state.value.profile}/mods"); dir.mkdirs(); downloaded.copyTo(File(dir,downloaded.name),true); downloaded.name }
   .onSuccess { n -> _state.update { it.copy(installing=false,notice="Instalado: $n") } }
   .onFailure { e -> _state.update { it.copy(installing=false,error=e.message ?: "Erro na instalação.") } }
 } }
 fun selectProfile(n:String) { _state.update { it.copy(profile=n) } }
 fun createProfile() { val n="Perfil ${_state.value.profiles.size+1}"; _state.update { it.copy(profiles=it.profiles+n,profile=n) } }
 fun setRam(v:Int) { _state.update { it.copy(ramGb=v) } }
 fun setRenderDistance(v:Int) { _state.update { it.copy(renderDistance=v) } }
 fun launchGame() { _state.update { it.copy(launchMessage="Falta integrar runtime Java Android, autenticação oficial e engine gráfica.") } }
}
