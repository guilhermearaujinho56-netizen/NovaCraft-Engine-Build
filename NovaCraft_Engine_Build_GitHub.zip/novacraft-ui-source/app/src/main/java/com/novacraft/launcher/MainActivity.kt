package com.novacraft.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { NovaCraftApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun NovaCraftApp(vm: LauncherViewModel = viewModel()) {
 var tab by remember { mutableIntStateOf(0) }
 val s by vm.state.collectAsState()
 MaterialTheme(colorScheme = darkColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF35D6D0), secondary = androidx.compose.ui.graphics.Color(0xFF8B9CFF))) {
  Scaffold(topBar = { TopAppBar(title = { Text("NOVACRAFT") }, actions = { Text("0.4.0", Modifier.padding(end=16.dp)) }) },
   bottomBar = { NavigationBar { listOf("Início","Mods","Perfis","Ajustes").forEachIndexed { i,n -> NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(when(i){0->Icons.Default.Home;1->Icons.Default.Extension;2->Icons.Default.Folder;else->Icons.Default.Settings},null)},label={Text(n)}) } } }) { pad ->
   Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
    when(tab) {
     0 -> { Text("Seu Minecraft, do seu jeito", style=MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(12.dp)); Card { Column(Modifier.padding(16.dp)) { Text("Perfil: ${s.profile}"); Text("Minecraft ${s.mcVersion} • ${s.loader}"); Text("RAM ${s.ramGb} GB • ${s.renderDistance} chunks"); Button(onClick={vm.launchGame()}, modifier=Modifier.fillMaxWidth()) { Text("JOGAR") }; Text(s.launchMessage) } }; Text("O motor Java ainda não está conectado nesta versão.") }
     1 -> ModsScreen(s,vm)
     2 -> { Text("Perfis", style=MaterialTheme.typography.headlineSmall); s.profiles.forEach { p -> Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) { Text(p,Modifier.weight(1f)); TextButton(onClick={vm.selectProfile(p)}) { Text(if(p==s.profile) "Ativo" else "Selecionar") } } }; Button(onClick={vm.createProfile}) { Text("Novo perfil") } }
     else -> { Text("Desempenho", style=MaterialTheme.typography.headlineSmall); Text("RAM: ${s.ramGb} GB"); Slider(s.ramGb.toFloat(),{vm.setRam(it.toInt().coerceIn(1,3))},valueRange=1f..3f,steps=1); Text("Renderização: ${s.renderDistance} chunks"); Slider(s.renderDistance.toFloat(),{vm.setRenderDistance(it.toInt())},valueRange=2f..12f,steps=4); Text("Em aparelhos com 4 GB, comece com 1–1,5 GB e 4 chunks.") }
    }
   }
  }
 }
}

@Composable fun ModsScreen(s: LauncherState, vm: LauncherViewModel) {
 var query by remember { mutableStateOf("") }; var source by remember { mutableStateOf("Modrinth") }
 var version by remember { mutableStateOf(s.mcVersion) }; var loader by remember { mutableStateOf("fabric") }
 OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Pesquisar mods")},singleLine=true)
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { FilterChip(source=="Modrinth",{source="Modrinth"},label={Text("Modrinth")}); FilterChip(source=="CurseForge",{source="CurseForge"},label={Text("CurseForge")}) }
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedTextField(version,{version=it},Modifier.weight(1f),label={Text("Versão MC")}); OutlinedTextField(loader,{loader=it},Modifier.weight(1f),label={Text("Loader")}) }
 Button(onClick={vm.searchMods(query,source,version,loader)},enabled=query.isNotBlank()&&!s.loading,modifier=Modifier.fillMaxWidth()) { Text(if(s.loading) "Buscando..." else "Buscar") }
 s.error?.let { Text(it,color=MaterialTheme.colorScheme.error) }; s.notice?.let { Text(it) }
 LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) { items(s.mods) { m -> Card { Column(Modifier.padding(12.dp)) { Text(m.title,style=MaterialTheme.typography.titleMedium); Text(m.description); Text("${m.source} • ${m.downloads} downloads"); Button(onClick={vm.installMod(m)},enabled=!s.installing) { Text(if(s.installing) "Instalando..." else "Instalar") } } } } }
}
