# NovaCraft Launcher 0.4 — fonte Android

Este ZIP contém um projeto Android Kotlin/Jetpack Compose, não um APK pronto.

## Já incluído
- Interface escura premium: Início, Mods, Perfis e Ajustes.
- Pesquisa pública de mods no Modrinth por Minecraft/loader.
- Download do primeiro arquivo compatível e verificação SHA-1 quando fornecida.
- Instalação do JAR no armazenamento privado do perfil selecionado.
- Perfis básicos e controles de RAM/distância.

## CurseForge
A tela oferece a opção, mas a chamada real exige backend HTTPS próprio com a chave oficial guardada como segredo no servidor. A chave nunca deve ficar dentro do APK. O endpoint de busca/versões ainda precisa ser implementado.

## Ainda NÃO está pronto
O botão JOGAR não abre Minecraft. Faltam runtime Java Android, autenticação Microsoft/Xbox/Minecraft, resolução integral de bibliotecas/arquivos, integração LWJGL/renderização/áudio/controles, integração com um engine Android (por exemplo, Amethyst, respeitando sua licença), e instaladores específicos de Forge/Fabric/NeoForge/Quilt/OptiFine. O instalador atual não resolve dependências nem conflitos.

## Compilação
Abra no Android Studio com JDK 17 e Android SDK 35 e execute `:app:assembleDebug`. O ZIP não inclui APK. Em um celular sem ambiente Android SDK/Gradle, será necessário usar um computador ou serviço de build remoto.

## Desempenho
Em aparelhos com 4 GB de RAM, comece com 1–1,5 GB para o jogo e 4 chunks; feche apps em segundo plano. Shaders e Vulkan dependem do driver e podem não funcionar.
